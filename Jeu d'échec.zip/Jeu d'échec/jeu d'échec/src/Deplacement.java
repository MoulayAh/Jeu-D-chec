import static java.lang.Character.isLowerCase;

public class Deplacement {
    public static boolean deplacementPion(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier) {
        if (Character.isUpperCase(echiquier[choixPionY-1][choixPionX])){
            if (choixDestY > choixPionY){
                System.out.println("interdit de reculer");
                return false;
            }
            else if (choixPionY-choixDestY > 1){
                if (choixPionY-1 == 6){
                    if (choixPionY-choixDestY > 2){
                        System.out.println("interdit d'avancer de trois");
                        return false;
                    }
                    else
                        return true;
                }
                else {
                    System.out.println("interdit d'avancer de deux");
                    return false;
                }
            }
            else if (choixDestX != choixPionX){
                if(isLowerCase(echiquier[choixDestY-1][choixDestX])){
                    return true;
                }
                else {
                    System.out.println("interdit d'aller sur le coté");
                    return false;
                }
            }
            else if(isLowerCase(echiquier[choixDestY-1][choixDestX])){
                System.out.println("obstacle devant");
                return false;
            }

        }
        else if(isLowerCase(echiquier[choixPionY-1][choixPionX])) {
            if (choixDestY < choixPionY){
                System.out.println("interdit de reculer");
                return false;
            }
            else if (choixDestY >  choixPionY+1){
                if (choixPionY-1 == 1){
                    if (choixDestY > choixPionY+2){
                        System.out.println("interdit d'avancer de trois");
                        return false;
                    }
                    else
                        return true;
                }
                else {
                    System.out.println("interdit d'avancer de deux");
                    return false;
                }
            }
            else if (choixDestX != choixPionX){
                if(Character.isUpperCase(echiquier[choixDestY-1][choixDestX])){
                    return true;
                }
                else {
                    System.out.println("interdit d'aller sur le coté");
                    return false;
                }
            }
            else if(Character.isUpperCase(echiquier[choixDestY-1][choixDestX])){
                System.out.println("obstacle devant");
                return false;
            }


        }

        return true;
    }

    public static boolean deplacementRoi(int choixPionX, int choixPionY, int choixDestY, int choixDestX){

        if (choixDestY < choixPionY-1){
            System.out.println("interdit de se deplacer de deux");
            return false;
        }
        if (choixDestX < choixPionX-1 || choixDestX > choixPionX+1){
            System.out.println("interdit de se deplacer de deux");
            return false;
        }

        return true;
    }

    public static boolean deplacementTour(char[][] echiquier, int choixPionX, int choixPionY, int choixDestY, int choixDestX) {
        if (choixPionX != choixDestX && choixPionY != choixDestY) {
            System.out.println("La tour ne peut se déplacer que horizontalement ou verticalement.");
            return false;
        }
        return true;
    }

    public static boolean deplacementChevalier( int choixPionX, int choixPionY, int choixDestY, int choixDestX) {

        int diffX;
        int diffY;

        if (choixDestX > choixPionX) {
            diffX = choixDestX - choixPionX;
        } else {
            diffX = choixPionX - choixDestX;
        }

        if (choixDestY > choixPionY) {
            diffY = choixDestY - choixPionY;
        } else {
            diffY = choixPionY - choixDestY;
        }

        // Vérifie si le déplacement correspond à un "L"
        if ((diffX == 2 && diffY == 1) || (diffX == 1 && diffY == 2)) {
            return true; // Déplacement valide
        } else {
            System.out.println("Déplacement invalide pour un cavalier.");
            return false;
        }
    }

    public static boolean petitRoqueBlanc(char[][] echiquier, int choixDestY, int choixDestX, int choixPionX, int choixPionY,int[] positionBlanc){
        if(choixPionX !=4 && choixPionY != 7 && choixDestY != 7 && choixDestX != 1){
            return false;
        }
        else if(Echec.echecBlanc(echiquier,positionBlanc)){
            return false;
        }
        else if(!Pions.colision( choixPionX,  choixPionY,  choixDestY,  choixDestX, echiquier)){
            return false;
        }
        else if(echiquier[7][4] != 'R' && echiquier[7][0] != 'T'){
            return false;
        }
        else if(echiquier[choixPionY-1][choixPionX] != 'R'){
            return false;
        }
        else if(choixDestX != 1 && choixDestY-1 != 7){
            return false;
        }
        else
            return true;
    }

    public static boolean petitRoqueNoir(char[][] echiquier, int choixDestY, int choixDestX, int choixPionX, int choixPionY,int[] positionNoir){
        if(choixPionX !=5 && choixPionY != 0 && choixDestY != 0 && choixDestX != 7){
            return false;
        }
        else if(Echec.echecNoir(echiquier,positionNoir)){
            return false;
        }
        else if(!Pions.colision( choixPionX,  choixPionY,  choixDestY,  choixDestX, echiquier)){
            return false;
        }
        else if(echiquier[0][5] != 'r' && echiquier[0][8] != 't'){
            return false;
        }
        else if(echiquier[choixPionY-1][choixPionX] != 'r'){
            return false;
        }
        else if(choixDestX != 7 && choixDestY-1 != 0){
            return false;
        }
        else
            return true;
    }

    public static boolean deplacementFou(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier) {
        // Calcul des différences entre les coordonnées
        int differenceX;
        int differenceY;

        if (choixDestX > choixPionX) {
            differenceX = choixDestX - choixPionX;
        } else {
            differenceX = choixPionX - choixDestX;
        }

        if (choixDestY > choixPionY) {
            differenceY = choixDestY - choixPionY;
        } else {
            differenceY = choixPionY - choixDestY;
        }

        // Vérifie si le mouvement est bien une diagonale
        if (differenceX != differenceY) {
            System.out.println("Déplacement invalide pour un fou.");
            return false;
        }

        // Vérifie qu'il n'y a pas d'obstacles sur le chemin
        int pasX;
        int pasY;

        // Détermine la direction de déplacement sur l'axe X
        if (choixDestX > choixPionX) {
            pasX = 1; // Vers la droite
        } else {
            pasX = -1; // Vers la gauche
        }

        // Détermine la direction de déplacement sur l'axe Y
        if (choixDestY > choixPionY) {
            pasY = 1; // Vers le bas
        } else {
            pasY = -1; // Vers le haut
        }


        return true;
    }


    public static boolean deplacementReine(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier) {

        //Deplacement comme la tour
        if(choixPionY-1 == choixDestY-1 || choixPionX == choixDestX){
            deplacementTour(echiquier,choixPionX,choixPionY,choixDestY,choixDestX);
        }
        //Deplacement comme le fou blanc
        else if (Math.abs(choixPionX - choixDestX) == Math.abs(choixDestY - choixPionY)) {
            deplacementFou(choixPionX,choixPionY,choixDestY,choixDestX,echiquier);
        }
        else{
            System.out.println("Vous avez fait un mouvement impossible");
            return false;
        }
        return true;
    }
}
