public class Echiquier {

    public static char[][] echiquier(){

        char[][] echiquier = new char[8][9];
        char c2 = '1';

        for (int i = 0 ; i < echiquier.length; i++){
            for (int j = 0; j < echiquier[i].length; j++){
                echiquier[i][j] = '-';
            }
        }

        for (int j = 0; j < echiquier.length; j++){
            echiquier[j][0] = c2;
            c2++;
        }

        return echiquier;
    }

    public static void echiquierAvecPieces(char[][] echiquier){
        char c2 = '8';

        for (int j = 0; j < echiquier.length; j++){
            echiquier[j][0] = c2;
            c2--;
        }

        for (int i = 1; i <= echiquier.length; i++){
            if (i == 1 || i == echiquier.length)
                echiquier[0][i] = 't';
            if(i == 2 || i == echiquier.length-1)
                echiquier[0][i] = 'c';
            if (i == 3 || i == echiquier.length-2)
                echiquier[0][i] = 'f';
        }
        echiquier[0][4] = 'q';
        echiquier[0][5] = 'r';
        for (int i = 1; i <= echiquier.length; i++){
            echiquier[1][i] = 'p';
        }
        for (int i = 1; i <= echiquier.length; i++){
            echiquier[echiquier.length-2][i] = 'P';
        }
        for (int i = 1; i <= echiquier.length; i++){
            if (i == 1 || i == echiquier.length)
                echiquier[echiquier.length-1][i] = 'T';
            if(i == 2 || i == echiquier.length-1)
                echiquier[echiquier.length-1][i] = 'C';
            if (i == 3 || i == echiquier.length-2)
                echiquier[echiquier.length-1][i] = 'F';
        }
        echiquier[echiquier.length-1][5] = 'Q';
        echiquier[echiquier.length-1][4] = 'R';

    }

    public static void affichage(char[][] echiquier){

        for (int colonne = 0; colonne < echiquier.length; colonne++){
            for (int ligne = 0; ligne < echiquier[colonne].length; ligne++){
                System.out.print(echiquier[colonne][ligne]);
                System.out.print(" ");
            }
            System.out.println();
        }
        System.out.println("  a b c d e f g h");
    }

}
