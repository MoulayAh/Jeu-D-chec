import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

            int choix;

            Scanner scanner = new Scanner(System.in);
            System.out.println("=============================================================================================");
            System.out.println("=============================================================================================");
            System.out.println("");
            System.out.println("\t\t\t      _______    _________               _______  _________");
            System.out.println("\t\t\t     /          /          /        /   /        /");
            System.out.println("\t\t\t    /          /          /        /   /        /");
            System.out.println("\t\t\t   /____      /          /________/   /____    /");
            System.out.println("\t\t\t  /          /          /        /   /        /");
            System.out.println("\t\t\t /          /          /        /   /        /");
            System.out.println("\t\t\t/______    /________  /        /   /______  /________  ");
            System.out.println("");
            System.out.println("=============================================================================================");
            System.out.println("=============================================================================================");
            System.out.println("\t\t\tFAIT PAR BOUDE HANOUNE | MOULAY AHMED EL JAMALI ");
            System.out.println("=============================================================================================");
            System.out.println("");
            do {
                System.out.println("\t\t\t 1.Le jeu \n\t\t\t 2.Jouer avec l'IA \n\t\t\t 3.Les règles \n\t\t\t 4.Quittez");
                System.out.println("=============================================================================================");
                choix = scanner.nextInt();

                switch (choix) {
                    case 1:
                        jeu1.jeu1v1();
                        break;
                    case 2 :
                        jeu1.jvb();
                    case 3:
                        Regle.choixdesregles();
                        break;
                }
            }while(choix != 4);


        }

    }
