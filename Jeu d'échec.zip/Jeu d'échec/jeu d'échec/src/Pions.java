import java.util.Scanner;

import static java.lang.Character.isLowerCase;

public class Pions {

    public static void bougerPion(char[][] echiquier, boolean tour){
        int choixPionX = 0;
        int choixPionY = 0;
        int choixDestX = 0;
        int choixDestY = 0;
        String choixPion;
        String choixDest;
        boolean verifPion;
        boolean verifPionS = false;
        boolean verifCol = false;
        boolean verifEchec = false;
        boolean verifChangement = true;
        int [] positionRoiBlanc ;
        int [] positionRoiNoir ;
        Scanner sc = new Scanner(System.in);


        do {

            System.out.println("choix pion");
            choixPion = sc.nextLine();
            System.out.println("choix destination");
            choixDest = sc.nextLine();

            while (choixPion.length() < 2 ||
                    choixDest.length() < 2 ||
                    choixDest.charAt(0)<'a' ||
                    choixDest.charAt(0)>'h' ||
                    choixDest.charAt(1)<'1' ||
                    choixDest.charAt(1)>'8' ||
                    choixPion.charAt(0)<'a' ||
                    choixPion.charAt(0)>'h' ||
                    choixPion.charAt(1)<'1' ||
                    choixPion.charAt(1)>'8' ||
                    choixDest.length()>2 ||
                    choixPion.length()>2){
                System.out.println("Erreur,\nchoix pion");
                choixPion = sc.nextLine();
                System.out.println("choix destination");
                choixDest = sc.nextLine();
            }

            for (char i = 'a'; i <= 'h'; i++){
                for (char j = '1'; j <= '8'; j++){
                    if (choixPion.charAt(0) == i && choixPion.charAt(1) == j){
                        choixPionX = i - '`';
                        choixPionY = 9-(j - '0');
                    }
                }
            }

            for (char i = 'a'; i <= 'h'; i++){
                for (char j = '1'; j <= '8'; j++){
                    if (choixDest.charAt(0) == i && choixDest.charAt(1) == j){
                        choixDestX = i - '`';
                        choixDestY = 9-(j - '0');
                    }
                }
            }

            positionRoiBlanc = Echec.trouverLeRoiBlanc(echiquier);
            positionRoiNoir = Echec.trouverLeRoiNoir(echiquier);

            switch (echiquier[choixPionY - 1][choixPionX]) {


                case 'P':  // Pion blanc
                case 'p':  // Pion noir
                    verifPionS = Deplacement.deplacementPion(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    verifCol = colision(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    break;

                case 'R':  // Roi blanc
                    int [] positionPiece = {choixPionY-1,choixPionX};
                    if(Deplacement.petitRoqueBlanc(echiquier,choixDestY, choixDestX, choixPionX, choixPionY,positionRoiBlanc)){
                        echiquier[7][1]= '-';
                        echiquier[7][3]= 'T';
                        verifPionS = true;
                        verifCol = true;
                    }
                    else {
                        verifPionS = Deplacement.deplacementRoi(choixPionX, choixPionY, choixDestY, choixDestX);
                        verifCol = colision(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    }
                    break;

                case 'r':  // Roi noir
                    if(Deplacement.petitRoqueNoir(echiquier,choixDestY, choixDestX, choixPionX, choixPionY,positionRoiNoir)){
                        echiquier[0][8]= '-';
                        echiquier[0][6]= 't';
                        verifPionS = true;
                        verifCol = true;
                    }
                    else{
                        verifPionS = Deplacement.deplacementRoi(choixPionX, choixPionY, choixDestY, choixDestX);
                        verifCol = colision(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    }

                    break;

                case 'T':  // Tour blanche
                case 't':  // Tour noire
                    verifPionS = Deplacement.deplacementTour(echiquier, choixPionX, choixPionY, choixDestY, choixDestX);
                    verifCol = colision(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    break;

                case 'C':  // Chevalier blanc
                case 'c':  // Chevalier noir
                    verifPionS = Deplacement.deplacementChevalier(choixPionX, choixPionY, choixDestY, choixDestX);
                    verifCol = true;
                    break;

                case 'F':  // Fou blanc
                case 'f':  // Fou noir
                    verifPionS = Deplacement.deplacementFou(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    verifCol = colision(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    break;

                case 'Q':  // Reine blanche
                case 'q':  // Reine noire
                    verifPionS = Deplacement.deplacementReine(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    verifCol = colision(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);
                    break;

                default:
                    // Si le caractère du pion ne correspond à rien (erreur de sélection)
                    verifPionS = false;
                    verifCol = false;
                    break;
            }

            if(Deplacement.petitRoqueBlanc(echiquier,choixDestY, choixDestX, choixPionX, choixPionY,positionRoiBlanc) || Deplacement.petitRoqueNoir(echiquier,choixDestY, choixDestX, choixPionX, choixPionY,positionRoiNoir)){
                verifPion = true;
            }
            else
                verifPion = verificationPieces(echiquier, choixPionX, choixPionY, choixDestY, choixDestX, tour);

            positionRoiBlanc = Echec.trouverLeRoiBlanc(echiquier);
            positionRoiNoir = Echec.trouverLeRoiNoir(echiquier);



        }while(!verifPion || !verifPionS || !verifCol || verifEchec);

        verifChangementPion(choixPionX, choixPionY, choixDestY, choixDestX, echiquier);

        echiquier[choixDestY - 1][choixDestX] = echiquier[choixPionY - 1][choixPionX];

        echiquier[choixPionY - 1][choixPionX] = '-';



        positionRoiBlanc = Echec.trouverLeRoiBlanc(echiquier);
        positionRoiNoir = Echec.trouverLeRoiNoir(echiquier);

        if (positionRoiBlanc == null || positionRoiNoir == null) {
            return;
        }

        Echec.echecBlanc(echiquier,positionRoiBlanc);
        Echec.echecNoir(echiquier,positionRoiNoir);
    }


    public static boolean verificationPieces(char[][] echiquier, int choixPionX, int choixPionY, int choixDestY, int choixDestX , boolean tour){


        if (echiquier[choixDestY-1][choixDestX] != '-' && ((isLowerCase(echiquier[choixPionY-1][choixPionX])&& isLowerCase(echiquier[choixDestY-1][choixDestX]))
        || (Character.isUpperCase(echiquier[choixDestY-1][choixDestX])&&Character.isUpperCase(echiquier[choixPionY-1][choixPionX])))){

            System.out.println("vous ne pouvez pas placer ce pion la !");
            return false ;

        }
        else {
            if(tour){
                if (echiquier[choixPionY-1][choixPionX] == 't'
                        || echiquier[choixPionY-1][choixPionX] == 'c'
                        || echiquier[choixPionY-1][choixPionX] == 'f'
                        || echiquier[choixPionY-1][choixPionX] == 'q'
                        || echiquier[choixPionY-1][choixPionX] == 'r'
                        || echiquier[choixPionY-1][choixPionX] == 'p'
                        || echiquier[choixPionY-1][choixPionX] == '-'){
                    System.out.println("Vous ne pouvez pas changer ce pion");
                    return false;
                }
            }
            else{
                if (echiquier[choixPionY-1][choixPionX] == 'T'
                        || echiquier[choixPionY-1][choixPionX] == 'C'
                        || echiquier[choixPionY-1][choixPionX] == 'F'
                        || echiquier[choixPionY-1][choixPionX] == 'Q'
                        || echiquier[choixPionY-1][choixPionX] == 'R'
                        || echiquier[choixPionY-1][choixPionX] == 'P'
                        || echiquier[choixPionY-1][choixPionX] == '-'){
                    System.out.println("Vous ne pouvez pas changer ce pion");
                    return false;
                }
            }
        }
        return true;
    }


    public static boolean colision(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier){
            int x1 = choixPionY-1, y1 = choixPionX;
            int x2 = choixDestY-1, y2 = choixDestX;

            // Vérification pour les mouvements en ligne droite (tour)
            if (x1 == x2) { // Déplacement horizontal
                int step = (y2 > y1) ? 1 : -1;
                for (int y = y1 + step; y != y2; y += step) {
                    if (echiquier[x1][y] != '-') { // Si la case n'est pas vide
                        System.out.println("Il ya un obstacle");
                        return false; // Un obstacle est rencontré
                    }
                }
            } else if (y1 == y2) { // Déplacement vertical
                int step = (x2 > x1) ? 1 : -1;
                for (int x = x1 + step; x != x2; x += step) {
                    if (echiquier[x][y1] != '-') { // Si la case n'est pas vide
                        System.out.println("Il ya un obstacle");
                        return false; // Un obstacle est rencontré
                    }
                }
            }
            // Vérification pour les mouvements en diagonale (fou)
            else if (Math.abs(x2 - x1) == Math.abs(y2 - y1)) { // Déplacement diagonal
                int stepX = (x2 > x1) ? 1 : -1;
                int stepY = (y2 > y1) ? 1 : -1;
                int x = x1 + stepX;
                int y = y1 + stepY;
                while (x != x2 && y != y2) {
                    if (echiquier[x][y] != '-') { // Si la case n'est pas vide
                        System.out.println("Il ya un obstacle");
                        return false; // Un obstacle est rencontré
                    }
                    x += stepX;
                    y += stepY;
                }
            } else {
                // Si le mouvement n'est ni en ligne droite ni en diagonale, ce n'est pas valide
                System.out.println("Il ya un obstacle");
                return false;
            }

            return true; // Aucun obstacle rencontré

    }



    public static void verifChangementPion(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier){

        int choix;
        Scanner sc = new Scanner(System.in);

        if (echiquier[choixPionY-1][choixPionX] == 'p' || echiquier[choixPionY-1][choixPionX] == 'P') {

            if (isLowerCase(echiquier[choixPionY - 1][choixPionX])) {
                if (choixDestY == 8) {
                    do {
                        System.out.println("Appuyez sur celui que vous voulez:\n1.Reine\n2.Tour\n3.Fou\n4.Cavalier");
                        choix = sc.nextInt();
                    } while (choix < 1 || choix > 4);
                    switch (choix) {
                        case 1:
                            echiquier[choixPionY - 1][choixPionX] = 'q';
                            break;
                        case 2:
                            echiquier[choixPionY - 1][choixPionX] = 't';
                            break;
                        case 3:
                            echiquier[choixPionY - 1][choixPionX] = 'f';
                            break;
                        case 4:
                            echiquier[choixPionY - 1][choixPionX] = 'c';
                            break;
                    }
                }
            } else {
                if (choixDestY == 1) {
                    do {
                        System.out.println("Appuyez sur celui que vous voulez:\n1.Reine\n2.Tour\n3.Fou\n4.Cavalier");
                        choix = sc.nextInt();
                    } while (choix < 1 || choix > 4);

                    switch (choix) {
                        case 1:
                            echiquier[choixPionY - 1][choixPionX] = 'Q';
                            break;
                        case 2:
                            echiquier[choixPionY - 1][choixPionX] = 'T';
                            break;
                        case 3:
                            echiquier[choixPionY - 1][choixPionX] = 'F';
                            break;
                        case 4:
                            echiquier[choixPionY - 1][choixPionX] = 'C';
                            break;
                    }
                }
            }
        }
    }

}