public class jeu1 {

    public static void jeu1v1() {
        char[][] echiquier;
        String[][] echiquierS;
        boolean tour = false;
        int cptTour = 0;

        String pseudo1 = Jeu.Pseudo1();
        String pseudo2 = Jeu.Pseudo2();
        echiquier = Echiquier.echiquier();
        Echiquier.echiquierAvecPieces(echiquier);
        echiquierS = Ascii.transformationDuCharEnAscii(echiquier);
        Ascii.afficherEchiquierString(echiquierS);

        //Echiquier.affichage(echiquier);



        while(Echec.trouverLeRoiBlanc(echiquier) != null || Echec.trouverLeRoiNoir(echiquier) != null) {
            if (cptTour % 2 == 0) {
                System.out.println("Au tour de " + pseudo1);
                tour = true;
            } else {
                System.out.println("Au tour de " + pseudo2);
                tour = false;
            }

            Pions.bougerPion(echiquier, tour);

            if (Echec.trouverLeRoiBlanc(echiquier) == null){
                System.out.println("=============================================================================================");
                System.out.println("\t\t\t Parti terminé, le gagnant est : " + pseudo1);
                System.out.println("=============================================================================================");
                break;
            }
            else if (Echec.trouverLeRoiNoir(echiquier) == null) {
                System.out.println("=============================================================================================");
                System.out.println("\t\t\t Parti terminé, le gagnant est : " + pseudo2);
                System.out.println("=============================================================================================");
                break;
            }

            echiquierS = Ascii.transformationDuCharEnAscii(echiquier);
            Ascii.afficherEchiquierString(echiquierS);
            //cptTour++;
        }


    }

    public static void jvb() {
        char[][] echiquier;
        String[][] echiquierS;
        boolean tour = false;
        int cptTour = 0;

        String pseudo1 = Jeu.Pseudo1();
        String pseudo2 = "ROBOT";
        echiquier = Echiquier.echiquier();
        Echiquier.echiquierAvecPieces(echiquier);
        echiquierS = Ascii.transformationDuCharEnAscii(echiquier);
        Ascii.afficherEchiquierString(echiquierS);

        //Echiquier.affichage(echiquier);



        while(Echec.trouverLeRoiBlanc(echiquier) != null || Echec.trouverLeRoiNoir(echiquier) != null) {
            if (cptTour % 2 == 0) {
                System.out.println("Au tour de " + pseudo1);
                tour = true;
                Pions.bougerPion(echiquier, tour);
            } else {
                System.out.println("Au tour de " + pseudo2);
                tour = false;
                PionsIa.bougerPion(echiquier, tour);
            }



            if (Echec.trouverLeRoiBlanc(echiquier) == null){
                System.out.println("Parti terminé, le gagnant est : " + pseudo1);
                break;
            }
            else if (Echec.trouverLeRoiNoir(echiquier) == null) {
                System.out.println("Parti terminé, le gagnant est : " + pseudo2);
                break;
            }

            echiquierS = Ascii.transformationDuCharEnAscii(echiquier);
            Ascii.afficherEchiquierString(echiquierS);
            cptTour++;
        }


    }
}
