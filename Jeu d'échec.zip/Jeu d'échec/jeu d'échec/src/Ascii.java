public class Ascii {
    // Déclaration caractères de l'échiquier
    // Déclaration pions blancs
    public static final String pionBlancAscii = "♙";
    public static final String cavalierBlancAscii = "♘";
    public static final String fouBlancAscii = "♗";
    public static final String tourBlancAscii = "♖";
    public static final String dameBlancAscii = "♕";
    public static final String roiBlancAscii = "♔";

    public static final String caseVide = "□";

    // Déclaration pions noirs
    public static final String pionNoirAscii = "♟";
    public static final String cavalierNoirAscii = "♞";
    public static final String fouNoirAscii = "♝";
    public static final String tourNoirAscii = "♜";
    public static final String dameNoirAscii = "♛";
    public static final String roiNoirAscii = "♚";



    public static void afficherEchiquierString(String[][] échiquier)  {
        System.out.println("  a b c d e f g h");

        for (int ligne = 0; ligne < échiquier.length; ligne++) {
            for (int colonne = 0; colonne < échiquier[ligne].length; colonne++) {
                System.out.print(échiquier[ligne][colonne]);
            }
            System.out.println();

        }
        System.out.println("  a b c d e f g h");
    }

    public static String[][] transformationDuCharEnAscii(char[][] echiquier) {
        String[][] echiquierDaffichage = new String[echiquier.length][echiquier[0].length];
        for (int i = 0; i < echiquierDaffichage.length; i++) {
            for (int j = 0; j < echiquierDaffichage[i].length; j++) {
                if (echiquier[i][j] == 't') {
                    echiquierDaffichage[i][j] = "♖ ";
                }
                else if (echiquier[i][j] == 'c') {
                    echiquierDaffichage[i][j] = "♘ ";
                }
                else if (echiquier[i][j] == 'f') {
                    echiquierDaffichage[i][j] = "♗ ";
                }
                else if (echiquier[i][j] == 'q') {
                    echiquierDaffichage[i][j] = "♕ ";
                }
                else if (echiquier[i][j] == 'r') {
                    echiquierDaffichage[i][j] = "♔ ";
                }
                else if (echiquier[i][j] == 'p') {
                    echiquierDaffichage[i][j] = "♙ ";
                }

                else if (echiquier[i][j] == 'T') {
                    echiquierDaffichage[i][j] = "♜ ";
                }
                else if (echiquier[i][j] == 'C') {
                    echiquierDaffichage[i][j] = "♞ ";
                }
                else if (echiquier[i][j] == 'F') {
                    echiquierDaffichage[i][j] = "♝ ";
                }
                else if (echiquier[i][j] == 'Q') {
                    echiquierDaffichage[i][j] = "♛ ";
                }
                else if (echiquier[i][j] == 'R') {
                    echiquierDaffichage[i][j] = "♚ ";
                }
                else if (echiquier[i][j] == 'P') {
                    echiquierDaffichage[i][j] = "♟ ";
                }
                else if (echiquier[i][j] == '-') {
                    echiquierDaffichage[i][j] = "⛉ ";
                    /*if (i%2==0){
                        if(j%2==0)
                            echiquierDaffichage[i][j] = "⛉ ";
                        else
                            echiquierDaffichage[i][j] = "⛊ ";
                    }
                    else {
                        if(j%2==0)
                            echiquierDaffichage[i][j] = "⛊ ";
                        else
                            echiquierDaffichage[i][j] = "⛉ ";
                    }*/
                }
                else if (echiquier[i][j] == '1') {
                    echiquierDaffichage[i][j] = "1 ";
                }
                else if (echiquier[i][j] == '2') {
                    echiquierDaffichage[i][j] = "2 ";
                }
                else if (echiquier[i][j] == '3') {
                    echiquierDaffichage[i][j] = "3 ";
                }
                else if (echiquier[i][j] == '4') {
                    echiquierDaffichage[i][j] = "4 ";
                }
                else if (echiquier[i][j] == '5') {
                    echiquierDaffichage[i][j] = "5 ";
                }
                else if (echiquier[i][j] == '6') {
                    echiquierDaffichage[i][j] = "6 ";
                }
                else if (echiquier[i][j] == '7') {
                    echiquierDaffichage[i][j] = "7 ";
                }
                else if (echiquier[i][j] == '8') {
                    echiquierDaffichage[i][j] = "8 ";
                }
            }
        }
        return echiquierDaffichage;
    }

}
