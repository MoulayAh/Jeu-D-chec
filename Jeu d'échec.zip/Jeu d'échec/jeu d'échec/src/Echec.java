import static java.lang.Character.isLowerCase;

public class Echec {


    public static boolean echecNoir(char[][] echiquier, int[] positionRoiNoir ){

        for (int i = 0; i < echiquier.length; i++){
            for (int j = 0; j < echiquier[i].length; j++){


                switch (echiquier[i][j]){
                    case 'P':
                        if (deplacementPion(j,i+1,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                            if (colision(j,i+1,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC PION !!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }

                        }
                        break;
                    case 'T' :
                        if (deplacementTour(echiquier,j,i,positionRoiNoir[0], positionRoiNoir[1])){
                            if (colision(j,i+1,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC TOUR !!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                    case 'C' :
                        if (deplacementChevalier(j,i,positionRoiNoir[0], positionRoiNoir[1])){
                            System.out.println("---------------------");
                            System.out.println("| ECHEC CHEVALIER ! |");
                            System.out.println("---------------------");
                            return true;

                        }
                        break;

                    case 'F' :
                        if (deplacementFou(j,i,positionRoiNoir[0], positionRoiNoir[1],echiquier)){
                            if (colision(j,i+1,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC FOU !!!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                    case 'Q' :
                        if (deplacementReine(j,i+1,positionRoiNoir[0]+1, positionRoiNoir[1],echiquier)){
                            if (colision(j,i+1,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC REINE !!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                    case 'R' :
                        if (deplacementRoi(j,i,positionRoiNoir[0],positionRoiNoir[1])){
                            if (colision(j,i+1,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC ROI !!!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                }
            }
        }
        return false;
    }



    public static boolean echecBlanc(char[][] echiquier,int[] positionRoiBlanc ){

        for (int i = 0; i < echiquier.length; i++){
            for (int j = 0; j < echiquier[i].length; j++){

                switch (echiquier[i][j]){
                    case 'p':
                        if (deplacementPion(j,i+1,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                            if (colision(j,i+1,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC PION !!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }

                        }
                        break;
                    case 't' :
                        if (deplacementTour(echiquier,j,i,positionRoiBlanc[0], positionRoiBlanc[1])){
                            if (colision(j,i+1,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC TOUR !!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                    case 'c' :
                        if (deplacementChevalier(j,i,positionRoiBlanc[0], positionRoiBlanc[1])){
                            System.out.println("---------------------");
                            System.out.println("| ECHEC CHEVALIER ! |");
                            System.out.println("---------------------");
                            return true;

                        }
                        break;

                    case 'f' :
                        if (deplacementFou(j,i,positionRoiBlanc[0], positionRoiBlanc[1],echiquier)){
                            if (colision(j,i+1,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC FOU !!!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                    case 'q' :
                        if (deplacementReine(j,i+1,positionRoiBlanc[0]+1, positionRoiBlanc[1],echiquier)){
                            if (colision(j,i+1,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC REINE !!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                    case 'r' :
                        if (deplacementRoi(j,i,positionRoiBlanc[0],positionRoiBlanc[1])){
                            if (colision(j,i+1,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                                System.out.println("---------------------");
                                System.out.println("| ECHEC ROI !!!!!!! |");
                                System.out.println("---------------------");
                                return true;
                            }
                        }
                        break;

                }
            }
        }
        return false;
    }

    public static boolean estEnEechecNoir(char[][] echiquier, int[] positionRoiNoir,int [] positionRoiBlanc ,int choixPionY, int choixPionX,int choixDestY,int choixDestX){

                switch (echiquier[choixPionY-1][choixPionX]){
                    case 'P':

                        System.out.println(choixDestY-1 +" " + choixDestX);
                        System.out.println(positionRoiNoir[0] +" " + positionRoiNoir[1]);

                        if (deplacementPion(choixDestX,choixDestY,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){

                            System.out.println("dep");

                            if (Pions.colision(choixDestX,choixDestY,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("echec pion");
                                return true;
                            }

                        }
                        break;
                    case 'T' :
                        if (deplacementTour(echiquier,choixDestX,choixDestY-1,positionRoiNoir[0], positionRoiNoir[1])){
                            if (colision(choixDestX,choixDestY,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("echec tour" );
                                return true;
                            }
                        }
                        break;

                    case 'C' :
                        if (deplacementChevalier(choixDestX,choixDestY-1,positionRoiNoir[0], positionRoiNoir[1])){
                            System.out.println("echec chevalier");
                            return true;

                        }
                        break;

                    case 'F' :
                        if (deplacementFou(choixDestX,choixDestY-1,positionRoiNoir[0], positionRoiNoir[1],echiquier)){
                            if (colision(choixDestX,choixDestY,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("echec fou" );
                                return true;
                            }
                        }
                        break;

                    case 'Q' :
                        if (deplacementReine(choixDestX,choixDestY,positionRoiNoir[0]+1, positionRoiNoir[1],echiquier)){
                            if (colision(choixDestX,choixDestY,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("echec reine" );
                                return true;
                            }
                        }
                        break;

                    case 'R' :
                        if (deplacementRoi(choixDestX,choixDestY-1,positionRoiNoir[0],positionRoiNoir[1])){
                            if (colision(choixDestX,choixDestY,positionRoiNoir[0]+1,positionRoiNoir[1],echiquier)){
                                System.out.println("echec roi" );
                                return true;
                            }
                        }
                        break;


                }
                return false;
    }

    public static boolean estEnEechecBlanc(char[][] echiquier, int[] positionRoiNoir,int [] positionRoiBlanc ,int choixPionY, int choixPionX,int choixDestY,int choixDestX){

        switch (echiquier[choixPionY-1][choixPionX]){
            case 'p':
                if (deplacementPion(choixDestX,choixDestY,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                    if (colision(choixDestX,choixDestY,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                        System.out.println("echec pion");
                        return true;
                    }

                }
                break;
            case 't' :
                if (deplacementTour(echiquier,choixDestX,choixDestY-1,positionRoiBlanc[0], positionRoiBlanc[1])){
                    if (colision(choixDestX,choixDestY,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                        System.out.println("echec tour" );
                        return true;
                    }
                }
                break;

            case 'c' :
                if (deplacementChevalier(choixDestX,choixDestY-1,positionRoiBlanc[0], positionRoiBlanc[1])){
                    System.out.println("echec chevalier");
                    return true;

                }
                break;

            case 'f' :
                if (deplacementFou(choixDestX,choixDestY-1,positionRoiBlanc[0], positionRoiBlanc[1],echiquier)){
                    if (colision(choixDestX,choixDestY,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                        System.out.println("echec fou" );
                        return true;
                    }
                }
                break;

            case 'q' :
                if (deplacementReine(choixDestX,choixDestY,positionRoiBlanc[0]+1, positionRoiBlanc[1],echiquier)){
                    if (colision(choixDestX,choixDestY,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                        System.out.println("echec reine" );
                        return true;
                    }
                }
                break;

            case 'r' :
                if (deplacementRoi(choixDestX,choixDestY-1,positionRoiBlanc[0],positionRoiBlanc[1])){
                    if (colision(choixDestX,choixDestY,positionRoiBlanc[0]+1,positionRoiBlanc[1],echiquier)){
                        System.out.println("echec roi" );
                        return true;
                    }
                }
                break;

        }
        return false;
    }




    public static int[] trouverLeRoiBlanc(char[][] echiquier) {
        for (int x = 0; x < echiquier.length; x++) {
            for (int y = 0; y < echiquier[x].length; y++) {
                if (echiquier[x][y] == 'R') { // Roi blanc
                    return new int[] {x, y};
                }
            }
        }
        return null; // Roi non trouvé
    }

    public static int[] trouverLeRoiNoir(char[][] echiquier) {
        for (int x = 0; x < echiquier.length; x++) {
            for (int y = 0; y < echiquier[x].length; y++) {
                if (echiquier[x][y] == 'r') { // Roi noir
                    return new int[] {x, y};
                }
            }
        }
        return null; // Roi non trouvé
    }

    public static boolean deplacementPion(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier) {
        if (Character.isUpperCase(echiquier[choixPionY-1][choixPionX])){
            if (choixDestY > choixPionY){
                return false;
            }
            else if (choixPionY-choixDestY > 1){
                if (choixPionY-1 == 6){
                    if (choixPionY-choixDestY > 2){
                        return false;
                    }
                    else
                        return true;
                }
                else {
                    return false;
                }
            }
            else if (choixDestX != choixPionX){
                if(isLowerCase(echiquier[choixDestY-1][choixDestX])){
                    return true;
                }
                else {
                    return false;
                }
            }
            else if(isLowerCase(echiquier[choixDestY-1][choixDestX])){
                return false;
            }

        }
        else if(isLowerCase(echiquier[choixPionY-1][choixPionX])) {
            if (choixDestY < choixPionY){
                return false;
            }
            else if (choixDestY >  choixPionY+1){
                if (choixPionY-1 == 1){
                    return true;
                }
                else {
                    return false;
                }
            }
            else if (choixDestX != choixPionX){
                if(Character.isUpperCase(echiquier[choixDestY-1][choixDestX])){
                    return true;
                }
                else {
                    return false;
                }
            }
            else if(Character.isUpperCase(echiquier[choixDestY-1][choixDestX])){
                return false;
            }


        }

        return true;
    }

    public static boolean deplacementRoi(int choixPionX, int choixPionY, int choixDestY, int choixDestX){

        if (choixDestY < choixPionY-1){
            return false;
        }
        if (choixDestX < choixPionX-1 || choixDestX > choixPionX+1){
            return false;
        }

        return true;
    }

    public static boolean deplacementTour(char[][] echiquier, int choixPionX, int choixPionY, int choixDestY, int choixDestX) {
        if (choixPionX != choixDestX && choixPionY != choixDestY) {
            return false;
        }
        return true;
    }

    public static boolean deplacementChevalier( int choixPionX, int choixPionY, int choixDestY, int choixDestX) {

        int diffX;
        int diffY;

        if (choixDestX > choixPionX) {
            diffX = choixDestX - choixPionX;
        } else {
            diffX = choixPionX - choixDestX;
        }

        if (choixDestY > choixPionY) {
            diffY = choixDestY - choixPionY;
        } else {
            diffY = choixPionY - choixDestY;
        }

        // Vérifie si le déplacement correspond à un "L"
        if ((diffX == 2 && diffY == 1) || (diffX == 1 && diffY == 2)) {
            return true; // Déplacement valide
        } else {
            return false;
        }
    }

    public static boolean deplacementFou(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier) {
        // Calcul des différences entre les coordonnées
        int differenceX;
        int differenceY;

        if (choixDestX > choixPionX) {
            differenceX = choixDestX - choixPionX;
        } else {
            differenceX = choixPionX - choixDestX;
        }

        if (choixDestY > choixPionY) {
            differenceY = choixDestY - choixPionY;
        } else {
            differenceY = choixPionY - choixDestY;
        }

        // Vérifie si le mouvement est bien une diagonale
        if (differenceX != differenceY) {
            return false;
        }

        // Vérifie qu'il n'y a pas d'obstacles sur le chemin
        int pasX;
        int pasY;

        // Détermine la direction de déplacement sur l'axe X
        if (choixDestX > choixPionX) {
            pasX = 1; // Vers la droite
        } else {
            pasX = -1; // Vers la gauche
        }

        // Détermine la direction de déplacement sur l'axe Y
        if (choixDestY > choixPionY) {
            pasY = 1; // Vers le bas
        } else {
            pasY = -1; // Vers le haut
        }


        return true;
    }


    public static boolean deplacementReine(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier) {

        //Deplacement comme la tour
        if(choixPionY-1 == choixDestY-1 || choixPionX == choixDestX){
            deplacementTour(echiquier,choixPionX,choixPionY,choixDestY,choixDestX);
        }
        //Deplacement comme le fou blanc
        else if (Math.abs(choixPionX - choixDestX) == Math.abs(choixDestY - choixPionY)) {
            deplacementFou(choixPionX,choixPionY,choixDestY,choixDestX,echiquier);
        }
        else{
            return false;
        }
        return true;
    }

    public static boolean colision(int choixPionX, int choixPionY, int choixDestY, int choixDestX, char[][] echiquier){
        int x1 = choixPionY-1, y1 = choixPionX;
        int x2 = choixDestY-1, y2 = choixDestX;

        // Vérification pour les mouvements en ligne droite (tour)
        if (x1 == x2) { // Déplacement horizontal
            int step = (y2 > y1) ? 1 : -1;
            for (int y = y1 + step; y != y2; y += step) {
                if (echiquier[x1][y] != '-') { // Si la case n'est pas vide
                    return false; // Un obstacle est rencontré
                }
            }
        } else if (y1 == y2) { // Déplacement vertical
            int step = (x2 > x1) ? 1 : -1;
            for (int x = x1 + step; x != x2; x += step) {
                if (echiquier[x][y1] != '-') { // Si la case n'est pas vide
                    return false; // Un obstacle est rencontré
                }
            }
        }
        // Vérification pour les mouvements en diagonale (fou)
        else if (Math.abs(x2 - x1) == Math.abs(y2 - y1)) { // Déplacement diagonal
            int stepX = (x2 > x1) ? 1 : -1;
            int stepY = (y2 > y1) ? 1 : -1;
            int x = x1 + stepX;
            int y = y1 + stepY;
            while (x != x2 && y != y2) {
                if (echiquier[x][y] != '-') { // Si la case n'est pas vide
                    return false; // Un obstacle est rencontré
                }
                x += stepX;
                y += stepY;
            }
        } else {
            // Si le mouvement n'est ni en ligne droite ni en diagonale, ce n'est pas valide
            return false;
        }

        return true; // Aucun obstacle rencontré

    }
/*
    public static boolean EchecEtMath(char[][] echiquier, int[] positionRoiNoir ){


    }
*/
}



