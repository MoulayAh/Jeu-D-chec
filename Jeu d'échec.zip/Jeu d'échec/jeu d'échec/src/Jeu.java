import java.util.Scanner;

public class Jeu {

    public static String Pseudo1() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel est le pseudo du joueur 1 ?");
        String pseudo1 = scanner.nextLine();
        return pseudo1;
    }
    public static String Pseudo2() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel est le pseudo du joueur 2 ?");
        String pseudo2 = scanner.nextLine();
        return pseudo2;
    }

    public static boolean aQuiLeTour(int compteur){
        if(compteur%2==0){
            return true;
        }
        else
            return false;
    }

    public static int[] traduisCoordonnées(String coordonneesEchecs) {
        int[] coordonnees = new int[2];
        char coordonnee1 = coordonneesEchecs.charAt(0); // tjrs dans l'exemple du dessus, prend le A
        char coordonnee2 = coordonneesEchecs.charAt(1); // Prends le 6
        switch (coordonnee1) {
            case 'A':
                coordonnees[1] = 0;
                break;
            case 'B':
                coordonnees[1] = 1;
                break;
            case 'C':
                coordonnees[1] = 2;
                break;
            case 'D':
                coordonnees[1] = 3;
                break;
            case 'E':
                coordonnees[1] = 4;
                break;
            case 'F':
                coordonnees[1] = 5;
                break;
            case 'G':
                coordonnees[1] = 6;
                break;
            case 'H':
                coordonnees[1] = 7;
                break;
        }
        switch (coordonnee2) {
            case '1':
                coordonnees[0] = 7;
                break;
            case '2':
                coordonnees[0] = 6;
                break;
            case '3':
                coordonnees[0] = 5;
                break;
            case '4':
                coordonnees[0] = 4;
                break;
            case '5':
                coordonnees[0] = 3;
                break;
            case '6':
                coordonnees[0] = 2;
                break;
            case '7':
                coordonnees[0] = 1;
                break;
            case '8':
                coordonnees[0] = 0;
                break;
        }
        return coordonnees;
    }

    //public static boolean joueur

}
