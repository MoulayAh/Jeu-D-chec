import java.util.Scanner;

public class Regle {
    static void choixdesregles() {
        int choix;

        Scanner scanner = new Scanner(System.in);

        do {
            System.out.println("1.pour les règles générales");
            System.out.println("2.pour les règles des pions");
            System.out.println("3.pour les règles des tours");
            System.out.println("4.pour les règles des cavaliers");
            System.out.println("5.pour les règles des fous");
            System.out.println("6.pour les règles des reines");
            System.out.println("7.pour les règles des rois");
            System.out.println("8.pour les règles de l’échec et mat");
            System.out.println("9.pour les règles des parties nulles");
            System.out.println("10.pour quittez");
            System.out.println("");
            choix = scanner.nextInt();

            switch (choix) {
                case 1:
                    System.out.println("1. Règles générales\n" +
                            "\n" +
                            "    L’échiquier est un plateau de 8x8 cases, alternant des couleurs claires et sombres.\n" +
                            "    Chaque joueur commence avec 16 pièces : 1 roi, 1 reine, 2 tours, 2 cavaliers, 2 fous et 8 pions.\n" +
                            "    Le but du jeu est de mettre le roi adverse en échec et mat (le roi est attaqué et ne peut pas échapper à la capture).\n" +
                            "    Les joueurs jouent à tour de rôle, en déplaçant une pièce à la fois.\n" +
                            "    Une pièce ne peut pas se déplacer sur une case occupée par une pièce alliée. Si elle se déplace sur une case occupée par une pièce ennemie, cette dernière est capturée.");
                    System.out.println("");
                    break;
                case 2:
                    System.out.println("2. Règles des pions\n" +
                            "\n" +
                            "    Les pions avancent tout droit, d’une case à la fois.\n" +
                            "    Lors de leur premier déplacement, les pions peuvent avancer de deux cases, mais seulement s’il n’y a pas d’obstacle sur leur chemin.\n" +
                            "    Les pions capturent en diagonale, mais ne peuvent pas avancer en diagonale si ce n’est pas pour capturer une pièce.\n" +
                            "    Si un pion atteint la dernière rangée de l’échiquier, il peut être promu en une autre pièce (reine, tour, cavalier ou fou).");
                    System.out.println("");
                    break;
                case 3:
                    System.out.println("3. Règles des tours\n" +
                            "\n" +
                            "    Les tours se déplacent horizontalement ou verticalement, sur n’importe quel nombre de cases, tant qu’il n’y a pas d’obstacle.\n" +
                            "    Les tours capturent en se déplaçant sur une case occupée par une pièce ennemie.\n" +
                            "    Une tour participe également à un mouvement spécial appelé roque (voir section sur le roi).");
                    System.out.println("");
                    break;
                case 4:
                    System.out.println("4. Règles des cavaliers\n" +
                            "\n" +
                            "    Les cavaliers se déplacent en forme de \"L\" : deux cases dans une direction (verticale ou horizontale) puis une case perpendiculaire, ou une case dans une direction et deux perpendiculaires.\n" +
                            "    Les cavaliers peuvent sauter par-dessus les autres pièces, qu’elles soient alliées ou ennemies.\n" +
                            "    Un cavalier capture en terminant son mouvement sur une case occupée par une pièce ennemie.");
                    System.out.println("");
                    break;
                case 5:
                    System.out.println("5. Règles des fous\n" +
                            "\n" +
                            "    Les fous se déplacent en diagonale, sur n’importe quel nombre de cases, tant qu’il n’y a pas d’obstacle.\n" +
                            "    Chaque fou est limité à une couleur de case tout au long du jeu (clair ou sombre).\n" +
                            "    Les fous capturent en se déplaçant sur une case occupée par une pièce ennemie.");
                    System.out.println("");
                    break;
                case 6:
                    System.out.println("6. Règles de la reine\n" +
                            "\n" +
                            "    La reine combine les mouvements de la tour et du fou : elle peut se déplacer horizontalement, verticalement ou en diagonale sur n’importe quel nombre de cases, tant qu’il n’y a pas d’obstacle.\n" +
                            "    La reine capture comme elle se déplace, en terminant son mouvement sur une case occupée par une pièce ennemie.");
                    System.out.println("");
                    break;
                case 7:
                    System.out.println("7. Règles du roi\n" +
                            "\n" +
                            "    Le roi peut se déplacer d’une case dans n’importe quelle direction (horizontale, verticale ou diagonale), à condition que la case ne soit pas attaquée par une pièce ennemie.\n" +
                            "    Le roi ne peut pas se déplacer sur une case où il serait en échec.\n" +
                            "    Le roi participe à un mouvement spécial appelé roque, où il échange de place avec une tour :\n" +
                            "        Cela ne peut être fait que si le roi et la tour concernés n’ont jamais bougé.\n" +
                            "        Il ne doit y avoir aucune pièce entre le roi et la tour.\n" +
                            "        Le roi ne peut pas être en échec, ni passer par ou finir sur une case attaquée.");
                    System.out.println("");
                    break;
                case 8:
                    System.out.println("8. Règles de l’échec et mat\n" +
                            "\n" +
                            "    Le roi est en échec lorsqu’il est attaqué par une ou plusieurs pièces ennemies.\n" +
                            "    Le joueur dont le roi est en échec doit faire un mouvement pour sortir de l’échec. Cela peut inclure :\n" +
                            "        Déplacer le roi vers une case sûre.\n" +
                            "        Capturer la pièce qui met en échec.\n" +
                            "        Bloquer l’attaque en interposant une pièce.\n" +
                            "    Si aucune de ces actions n’est possible, le roi est en échec et mat, et le joueur perd la partie.");
                    System.out.println("");
                    break;
                case 9:
                    System.out.println("9. Règles des parties nulles\n" +
                            "\n" +
                            "Une partie peut être nulle dans les cas suivants :\n" +
                            "\n" +
                            "    Les deux joueurs conviennent d’un match nul.\n" +
                            "    Un joueur n’a aucun coup légal à jouer, mais son roi n’est pas en échec (pat).\n" +
                            "    Une position se répète trois fois (règle de la triple répétition).\n" +
                            "    Il y a 50 coups consécutifs sans qu’un pion ne soit déplacé ni qu’une pièce soit capturée.\n" +
                            "    Il n’est pas possible de mater avec les pièces restantes (par exemple, un roi contre un roi, ou un roi et un fou contre un roi).");
                    System.out.println("");
                    break;
            }

        } while (choix != 10);
    }
}